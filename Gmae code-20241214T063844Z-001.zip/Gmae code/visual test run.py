visual_score = 48

if visual_score < 15:
    print("You KNOW you are in a room?")
elif 15 <= visual_score < 20:
    print("The room? is adorned with intricate carvings and glowing symbols.")
elif 20 <= visual_score < 35:
    print("The walls? shimmer with a mesmerizing, otherworldly glow.")
elif 35 <= visual_score < 50:
    print("A majestic chandelier illuminates the room? with golden light.")
elif visual_score >= 50:
    print("The boundaries shimmer with an otherworldly glow as majestic phantoms flow in and out of view.")
