#Ash Cowne
#11/26/2024
#P5HW_Using AI
#Making a game in java with the help of AI.

import random

# Function to create the "room" display
def display_room(character=None, question=None, visual_score=0):
    print("\n" + "=" * 60)
    print("You are in a detailed room. There's a screen in front of you.")
    
    # Display health in the top-right corner
    if character:
        print(f"{' ' * 40}Health: {character['health']}/{character['max_health']}")
    else:
        print(f"{' ' * 40}Health: N/A")

    print("=" * 60)

    # Add a single room detail based on the visual score
    print("You think you are in a room?")
    
    if visual_score < 20:
        print("You KNOW you are in a room?")
    eliff 20 <= visual_score < 30:
        print("The room? is adorned with intricate carvings and glowing symbols.")
    elif 30 <= visual_score < 55:
        print("The walls? shimmer with a mesmerizing, otherworldly glow.")
    elif 55 <= visual_score < 90:
        print("A majestic chandelier illuminates the room? with golden light.")
    elif visual_score >= 90:
        print("The boundaries shimmer with an otherworldly glow as majestic phantoms flow in and out of view.")

    print("Answer the question correctly to escape, but be warned, if you fail, you'll be harmed.")

    # Display the screen with the question
    if question:
        print("\n" + " " * 20 + "=== SCREEN ===")
        print(" " * 20 + f"{question}")
        print(" " * 20 + "==============")
    else:
        print("\nNo questions displayed right now.")

    print("=" * 60)



# Updated solve_puzzle function
def solve_puzzle(character):
    if character["health"] <= 0:
        print(f"{character['name']} has 0 health and cannot solve puzzles.")
        return character

    def redistribute_stat(character, points):
        """Redistributes stat points with a difficulty multiplier."""
        stats = ["Strength", "Dexterity", "Constitution", "Intelligence", "Wisdom", "Charisma"]
        for _ in range(points):
            available_stats = [stat for stat in stats if character[stat] < 50]
            if available_stats:
                chosen_stat = random.choice(available_stats)
                character[chosen_stat] += 1
                print(f"Stat point added to {chosen_stat}.")
            else:
                print("All stats are maxed out!")

    def ask_question(puzzles, visual_score):
        """Presents a random question to the player."""
        puzzle = random.choice(puzzles)
        display_room(character, puzzle["question"], visual_score)
        user_answer = input("\nYour Answer: ")
        return user_answer.lower() == puzzle["answer"].lower(), puzzle["difficulty"]

    # Visual score calculation
    max_stat_value = 50
    visual_score = ((character["Charisma"] / max_stat_value) * 20 +((character["Wisdom"] + character["Intelligence"]) / (2 * max_stat_value)) * 15 +((character["Strength"] + character["Dexterity"] + character["Constitution"]) / (3 * max_stat_value)) * 15)

    # Puzzle pools
    puzzles_easy = [
        {"question": "What is 5 + 3?", "answer": "8", "difficulty": 5},
        {"question": "What is 12 - 4?", "answer": "8", "difficulty": 5},
        {"question": "What is 3 * 7?", "answer": "21", "difficulty": 5},
        {"question": "What is 15 / 3?", "answer": "5", "difficulty": 5},
        {"question": "What is the capital of France?", "answer": "Paris", "difficulty": 5},
    ]

    puzzles_normal = [
        {"question": "What is the square root of 144?", "answer": "12", "difficulty": 10},
        {"question": "What is 25 * 6?", "answer": "150", "difficulty": 10},
        {"question": "Who wrote 'Hamlet'?", "answer": "Shakespeare", "difficulty": 10},
        {"question": "What is the chemical symbol for water?", "answer": "H2O", "difficulty": 10},
        {"question": "What is the cube root of 27?", "answer": "3", "difficulty": 10},
    ]

    puzzles_hard = [
        {"question": "What is 19 * 17?", "answer": "323", "difficulty": 15},
        {"question": "What is the speed of light in m/s?", "answer": "299792458", "difficulty": 15},
        {"question": "Solve: (6 * 3) - (4 / 2) + 5", "answer": "21", "difficulty": 15},
        {"question": "Name the author of 'The Origin of Species'.", "answer": "Darwin", "difficulty": 15},
        {"question": "What is the atomic number of gold?", "answer": "79", "difficulty": 15},
    ]

    # Initial difficulty
    difficulty = "easy"
    correct_answers = 0

    while True:
        # Select puzzle pool based on difficulty
        if difficulty == "easy":
            puzzles = puzzles_easy
            damage_multiplier = 1
        elif difficulty == "normal":
            puzzles = puzzles_normal
            damage_multiplier = 2
        elif difficulty == "hard":
            puzzles = puzzles_hard
            damage_multiplier = 3

        # Ask a question
        correct, puzzle_difficulty = ask_question(puzzles, visual_score)
        if correct:
            print("\nCorrect!")
            correct_answers += 1

            # Award stat points and heal
            bonus_points = 1 if difficulty == "easy" else 2 if difficulty == "normal" else 3
            redistribute_stat(character, bonus_points)
            
            # Heal based on difficulty
            health_restore = random.randint(1, 5) * bonus_points
            character["health"] = min(character["max_health"], character["health"] + health_restore)
            print(f"{character['name']} regained {health_restore} health (Current Health: {character['health']}/{character['max_health']}).")

            # Update difficulty
            if correct_answers == 5 and difficulty == "easy":
                difficulty = "normal"
                print("\nYou've advanced to Normal difficulty puzzles!")
            elif correct_answers == 10 and difficulty == "normal":
                difficulty = "hard"
                print("\nYou've advanced to Hard difficulty puzzles!")

            # Continue or leave
            choice = input("\nDo you want to continue solving puzzles? (yes/no): ").strip().lower()
            if choice == "no":
                break
        else:
            # Handle incorrect answers and damage
            print("\nIncorrect! You need to answer the next question correctly to escape.")
            damage_roll = random.randint(1, 10) * damage_multiplier
            character["health"] = max(0, character["health"] - damage_roll)
            print(f"{character['name']} took {damage_roll} damage (Current Health: {character['health']}/{character['max_health']}).")

            if character["health"] <= 0:
                print(f"{character['name']} has run out of health!")
                return character

    return character



# Function to create a character
def create_character():
    if len(characters) >= 5:
        print("You can only create up to 5 characters.")
        return None

    name = input("Enter the character's name: ")
    points_to_allocate = 50  # Total points to allocate

    stats = {
        "Strength": 0,
        "Dexterity": 0,
        "Constitution": 0,
        "Intelligence": 0,
        "Wisdom": 0,
        "Charisma": 0
    }

    print("\nAllocate 50 points across the following stats (max 50 per stat):")
    stat_numbers = {1: "Strength", 2: "Dexterity", 3: "Constitution", 
                    4: "Intelligence", 5: "Wisdom", 6: "Charisma"}

    while points_to_allocate > 0:
        print(f"\nPoints remaining: {points_to_allocate}")
        for number, stat in stat_numbers.items():
            print(f"{number}. {stat}: {stats[stat]}")

        try:
            stat_choice = int(input("Select the stat number to increase: "))
            if stat_choice not in stat_numbers:
                print("Invalid selection. Choose a valid stat number.")
                continue

            stat_to_increase = stat_numbers[stat_choice]
            points = int(input(f"How many points to add to {stat_to_increase}? "))
            if points <= 0 or points > points_to_allocate or stats[stat_to_increase] + points > 50:
                print("Invalid allocation. Check the limits and try again.")
                continue

            stats[stat_to_increase] += points
            points_to_allocate -= points
        except ValueError:
            print("Please enter valid numbers for your selection and points.")
            continue

    # Calculate initial health with a base value of 5
    base_health = 5 + (stats["Constitution"] * 10) + ((stats["Strength"] + stats["Dexterity"]) // 2)
    max_health = base_health

    # Return the new character
    character = {
        "name": name,
        "health": max_health,
        "max_health": max_health,
        "stat_points": 0,  # Points earned through puzzles
        **stats  # Add stats to the character dictionary
    }
    return character


# Function to display all characters
def display_characters(character_list):
    for character in character_list:
        print(f"\nName: {character['name']}")
        print(f"Health: {character['health']} / {character['max_health']}")
        for stat in ["Strength", "Dexterity", "Constitution", "Intelligence", "Wisdom", "Charisma"]:
            print(f"{stat}: {character[stat]}")

# Main function
def main():
    global characters
    characters = []  # List to hold all characters

    while True:
        print("\n--- Main Menu ---")
        print("1. Create a new character")
        print("2. Display all characters")
        print("3. Solve a puzzle")
        print("4. Exit")
        
        choice = input("Choose an option (1-4): ")
        
        if choice == "1":
            new_character = create_character()
            if new_character:
                characters.append(new_character)
        
        elif choice == "2":
            if characters:
                display_characters(characters)
            else:
                print("\nNo characters created yet.")
        
        elif choice == "3":
            if characters:
                print("\nChoose a character to solve a puzzle:")
                for idx, character in enumerate(characters):
                    status = " (Unusable)" if character["health"] == 0 else ""
                    print(f"{idx + 1}. {character['name']}{status}")
                
                try:
                    char_idx = int(input("\nSelect a character (number): ")) - 1
                    if char_idx < 0 or char_idx >= len(characters):
                        print("Invalid choice. Try again.")
                        continue
                    
                    selected_character = characters[char_idx]
                    characters[char_idx] = solve_puzzle(selected_character)
                except ValueError:
                    print("Please enter a valid number.")
            else:
                print("\nYou need to create characters first.")
        
        elif choice == "4":
            print("\nThanks for playing! Exiting...")
            break
        
        else:
            print("\nInvalid choice. Please select a valid option.")

if __name__ == "__main__":
    main()

