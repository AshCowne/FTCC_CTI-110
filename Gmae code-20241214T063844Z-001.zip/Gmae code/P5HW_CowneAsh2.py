#Ash Cowne
#11/26/2024
#P5HW_Using AI
#Making a game in java with the help of AI.

import random

# Function to create the "room" display
def display_room(character=None, question=None, visual_score=0):
    print("\n" + "=" * 60)
    print("You are in a detailed room. There's a screen in front of you.")
    
    # Display health in the top-right corner
    if character:
        print(f"{' ' * 40}Health: {character['health']}/{character['max_health']}")
    else:
        print(f"{' ' * 40}Health: N/A")

    print("=" * 60)

    # Add detail to the room based on the visual score
    details = int(visual_score // 10)  # Convert to integer for range()
    for _ in range(details):
        print("The room is adorned with intricate carvings and glowing symbols.")
    
    if visual_score >= 30:
        print("A majestic chandelier illuminates the room with golden light.")
    if visual_score >= 50:
        print("The walls shimmer with a mesmerizing, otherworldly glow.")
    
    # Display the screen with the question
    if question:
        print("\n" + " " * 20 + "=== SCREEN ===")
        print(" " * 20 + f"{question}")
        print(" " * 20 + "==============")
    else:
        print("\nNo questions displayed right now.")

    print("=" * 60)


# Updated solve_puzzle function
def solve_puzzle(character):
    if character["health"] <= 0:
        print(f"{character['name']} has 0 health and cannot solve puzzles.")
        return character

    # Calculate the visual score
    visual_score = character["Charisma"] + ((character["Wisdom"] + character["Intelligence"]) / 10)
    visual_score += (character["Strength"] // 5) + (character["Dexterity"] // 5) + (character["Constitution"] // 5)

    # Puzzles and their difficulty
    puzzles = [
        {"question": "What is 5 + 3?", "answer": "8", "difficulty": 10},
        {"question": "What is 12 - 4?", "answer": "8", "difficulty": 10},
        {"question": "What is 3 * 7?", "answer": "21", "difficulty": 15},
        {"question": "What is 15 / 3?", "answer": "5", "difficulty": 5},
        {"question": "What is the capital of France?", "answer": "Paris", "difficulty": 20},
    ]

    puzzle = random.choice(puzzles)

    # Display the room and the question
    display_room(character, puzzle["question"], visual_score)
    user_answer = input("\nYour Answer: ")

    # Handle correct and incorrect answers
    if user_answer.lower() == puzzle['answer'].lower():
        # Choose a random stat to increment
        random_stat = random.choice(["Strength", "Dexterity", "Constitution", 
                                     "Intelligence", "Wisdom", "Charisma"])
        if character[random_stat] < 20:
            character[random_stat] += 1
            print(f"\nCorrect! 1 point added to {random_stat}.")
        else:
            print(f"\nCorrect! But {random_stat} is already maxed out.")
    else:
        # Calculate damage based on character stats
        damage = puzzle["difficulty"]
        damage_taken = round(damage / (((character["Constitution"] / (character["Dexterity"] / 2)) / 10)), 2)
        print(f"\nIncorrect! You lost {damage_taken} health.")
        character["health"] -= damage_taken

    # Ensure health doesn't go below 0
    if character["health"] < 0:
        character["health"] = 0

    return character

# Function to create a character
def create_character():
    if len(characters) >= 5:
        print("You can only create up to 5 characters.")
        return None

    name = input("Enter the character's name: ")
    points_to_allocate = 50  # Total points to allocate

    stats = {
        "Strength": 0,
        "Dexterity": 0,
        "Constitution": 0,
        "Intelligence": 0,
        "Wisdom": 0,
        "Charisma": 0
    }

    print("\nAllocate 50 points across the following stats (max 20 per stat):")
    stat_numbers = {1: "Strength", 2: "Dexterity", 3: "Constitution", 
                    4: "Intelligence", 5: "Wisdom", 6: "Charisma"}

    while points_to_allocate > 0:
        print(f"\nPoints remaining: {points_to_allocate}")
        for number, stat in stat_numbers.items():
            print(f"{number}. {stat}: {stats[stat]}")
        
        try:
            stat_choice = int(input("Select the stat number to increase: "))
            if stat_choice not in stat_numbers:
                print("Invalid selection. Choose a valid stat number.")
                continue
            
            stat_to_increase = stat_numbers[stat_choice]
            points = int(input(f"How many points to add to {stat_to_increase}? "))
            if points <= 0 or points > points_to_allocate or stats[stat_to_increase] + points > 20:
                print("Invalid allocation. Check the limits and try again.")
                continue

            stats[stat_to_increase] += points
            points_to_allocate -= points
        except ValueError:
            print("Please enter valid numbers for your selection and points.")
            continue

    # Calculate initial health based on Constitution
    max_health = 100 + (stats["Constitution"] * 5)

    # Return the new character
    character = {
        "name": name,
        "health": max_health,
        "max_health": max_health,
        "stat_points": 0,  # Points earned through puzzles
        **stats  # Add stats to the character dictionary
    }
    return character

# Function to display all characters
def display_characters(character_list):
    for character in character_list:
        print(f"\nName: {character['name']}")
        print(f"Health: {character['health']} / {character['max_health']}")
        for stat in ["Strength", "Dexterity", "Constitution", "Intelligence", "Wisdom", "Charisma"]:
            print(f"{stat}: {character[stat]}")

# Main function
def main():
    global characters
    characters = []  # List to hold all characters

    while True:
        print("\n--- Main Menu ---")
        print("1. Create a new character")
        print("2. Display all characters")
        print("3. Solve a puzzle")
        print("4. Exit")
        
        choice = input("Choose an option (1-4): ")
        
        if choice == "1":
            new_character = create_character()
            if new_character:
                characters.append(new_character)
        
        elif choice == "2":
            if characters:
                display_characters(characters)
            else:
                print("\nNo characters created yet.")
        
        elif choice == "3":
            if characters:
                print("\nChoose a character to solve a puzzle:")
                for idx, character in enumerate(characters):
                    status = " (Unusable)" if character["health"] == 0 else ""
                    print(f"{idx + 1}. {character['name']}{status}")
                
                try:
                    char_idx = int(input("\nSelect a character (number): ")) - 1
                    if char_idx < 0 or char_idx >= len(characters):
                        print("Invalid choice. Try again.")
                        continue
                    
                    selected_character = characters[char_idx]
                    characters[char_idx] = solve_puzzle(selected_character)
                except ValueError:
                    print("Please enter a valid number.")
            else:
                print("\nYou need to create characters first.")
        
        elif choice == "4":
            print("\nThanks for playing! Exiting...")
            break
        
        else:
            print("\nInvalid choice. Please select a valid option.")

if __name__ == "__main__":
    main()
