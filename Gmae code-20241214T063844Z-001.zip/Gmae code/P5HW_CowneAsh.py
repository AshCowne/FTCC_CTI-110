#Ash Cowne
#11/26/2024
#P5HW_Using AI
#Making a game in java with the help of AI.

import random

# Function to calculate the visual score
def calculate_visual_score(character):
    return (
        character["Charisma"] 
        + (character["Wisdom"] + character["Intelligence"]) / 10 
        + (character["Strength"] + character["Dexterity"] + character["Constitution"]) / 5
    )

# Function to display graphics based on visual score
def display_graphics(character):
    visual_score = calculate_visual_score(character)
    print(f"\n--- Visual Score: {visual_score:.2f} ---")
    print("Graphics:")

    # Base graphic (low detail)
    print("  o")
    print(" /|\\")
    print(" / \\")

    # Add details based on visual score
    if visual_score >= 10:
        print("  :)  <-- A smile appears")
    if visual_score >= 20:
        print(" /|\\  <-- Arms extended in detail")
        print(" / \\")
    if visual_score >= 30:
        print(" | |  <-- Adding background detail (a shield)")
    if visual_score >= 40:
        print(" ^^^  <-- Ground detail added")
    if visual_score >= 50:
        print(" **** <-- Starry background added")
    if visual_score >= 60:
        print("  ||  <-- Complete scene with a tree and surroundings")

# Step 1: Function to create a character with D&D stats
def create_character():
    if len(characters) >= 5:
        print("You can only create up to 5 characters.")
        return None

    name = input("Enter the character's name: ")
    points_to_allocate = 50  # Total points to allocate

    stats = {
        "Strength": 0,
        "Dexterity": 0,
        "Constitution": 0,
        "Intelligence": 0,
        "Wisdom": 0,
        "Charisma": 0
    }

    print("\nAllocate 50 points across the following stats (max 20 per stat):")
    stat_numbers = {1: "Strength", 2: "Dexterity", 3: "Constitution", 
                    4: "Intelligence", 5: "Wisdom", 6: "Charisma"}

    while points_to_allocate > 0:
        print(f"\nPoints remaining: {points_to_allocate}")
        for number, stat in stat_numbers.items():
            print(f"{number}. {stat}: {stats[stat]}")
        
        try:
            stat_choice = int(input("Select the stat number to increase: "))
            if stat_choice not in stat_numbers:
                print("Invalid selection. Choose a valid stat number.")
                continue
            
            stat_to_increase = stat_numbers[stat_choice]
            points = int(input(f"How many points to add to {stat_to_increase}? "))
            if points <= 0 or points > points_to_allocate or stats[stat_to_increase] + points > 20:
                print("Invalid allocation. Check the limits and try again.")
                continue

            stats[stat_to_increase] += points
            points_to_allocate -= points
        except ValueError:
            print("Please enter valid numbers for your selection and points.")
            continue

    # Calculate initial health based on Constitution
    max_health = 100 + (stats["Constitution"] * 5)

    # Return the new character
    character = {
        "name": name,
        "health": max_health,
        "max_health": max_health,
        "stat_points": 0,  # Points earned through puzzles
        **stats  # Add stats to the character dictionary
    }
    return character

# Step 2: Function to display all characters
def display_characters(character_list):
    for character in character_list:
        print(f"\nName: {character['name']}")
        print(f"Health: {character['health']} / {character['max_health']}")
        print(f"Unallocated Stat Points: {character['stat_points']}")
        for stat in ["Strength", "Dexterity", "Constitution", "Intelligence", "Wisdom", "Charisma"]:
            print(f"{stat}: {character[stat]}")
        display_graphics(character)

# Step 3: Function to solve puzzles
def solve_puzzle(character):
    if character["health"] <= 0:
        print(f"{character['name']} has 0 health and cannot solve puzzles.")
        return character

    puzzles = [
        {"question": "What is 5 + 3?", "answer": "8", "difficulty": 10},
        {"question": "What is 12 - 4?", "answer": "8", "difficulty": 10},
        {"question": "What is 3 * 7?", "answer": "21", "difficulty": 15},
        {"question": "What is 15 / 3?", "answer": "5", "difficulty": 5},
        {"question": "What is the capital of France?", "answer": "Paris", "difficulty": 20},
    ]

    puzzle = random.choice(puzzles)
    print(f"\n{character['name']}, solve this puzzle to maintain your health!")
    user_answer = input(f"Question: {puzzle['question']} ")

    if user_answer.lower() == puzzle['answer'].lower():
        print(f"Correct! You gained 1 stat point.")
        character["stat_points"] += 1
    else:
        damage = puzzle["difficulty"]
        damage_taken = round(damage / (((character["Constitution"] / (character["Dexterity"] / 2)) / 10)), 2)
        print(f"Incorrect! You lost {damage_taken} health.")
        character["health"] -= damage_taken

    # Ensure health doesn't go below 0
    if character["health"] < 0:
        character["health"] = 0

    return character

# Main function to control the flow of the game
def main():
    global characters
    characters = []  # List to hold all characters

    while True:
        print("\n--- Main Menu ---")
        print("1. Create a new character")
        print("2. Display all characters")
        print("3. Solve a puzzle")
        print("4. Exit")
        
        choice = input("Choose an option (1-4): ")
        
        if choice == "1":
            new_character = create_character()
            if new_character:
                characters.append(new_character)
        
        elif choice == "2":
            if characters:
                display_characters(characters)
            else:
                print("\nNo characters created yet.")
        
        elif choice == "3":
            if characters:
                print("\nChoose a character to solve a puzzle:")
                for idx, character in enumerate(characters):
                    status = " (Unusable)" if character["health"] == 0 else ""
                    print(f"{idx + 1}. {character['name']}{status}")
                
                try:
                    char_idx = int(input("\nSelect a character (number): ")) - 1
                    if char_idx < 0 or char_idx >= len(characters):
                        print("Invalid choice. Try again.")
                        continue
                    
                    selected_character = characters[char_idx]
                    characters[char_idx] = solve_puzzle(selected_character)
                except ValueError:
                    print("Please enter a valid number.")
            else:
                print("\nYou need to create characters first.")
        
        elif choice == "4":
            print("\nThanks for playing! Exiting...")
            break
        
        else:
            print("\nInvalid choice. Please select a valid option.")

if __name__ == "__main__":
    main()
